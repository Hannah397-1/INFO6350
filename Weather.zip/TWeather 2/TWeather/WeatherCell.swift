//
//  WeatherCell.swift
//  TWeather
//
//  Created by Xiaohan on 2022/11/20.
//

import UIKit

class WeatherCell: UITableViewCell {
    
    var bgView: UIView = {
        let v = UIView()
        v.layer.cornerRadius = 10
        v.layer.borderWidth = 0.5
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.borderColor = UIColor.orange.cgColor
        return v
    }()
    
    var tempLabel: UILabel = {
        let label = UILabel()
        label.text = "1111"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var dateLabel: UILabel = {
        let label = UILabel()
        label.text = "22222"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var conditionLabel: UILabel = {
        let label = UILabel()
        label.text = "33333"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        self.contentView.addSubview(self.bgView)
        self.bgView.addSubview(self.tempLabel)
        self.bgView.addSubview(self.conditionLabel)
        self.bgView.addSubview(self.dateLabel)
        
        self.bgView.leftAnchor.constraint(equalTo: self.contentView.leftAnchor, constant: 20).isActive = true
        self.bgView.rightAnchor.constraint(equalTo: self.contentView.rightAnchor, constant: -20).isActive = true
        self.bgView.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 20).isActive = true
        self.bgView.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -20).isActive = true
        
        self.tempLabel.leftAnchor.constraint(equalTo: self.bgView.leftAnchor, constant: 10).isActive = true
        self.tempLabel.topAnchor.constraint(equalTo: self.bgView.topAnchor, constant: 10).isActive = true
        
        self.conditionLabel.leftAnchor.constraint(equalTo: self.bgView.leftAnchor, constant: 10).isActive = true
        self.conditionLabel.topAnchor.constraint(equalTo: self.tempLabel.bottomAnchor, constant: 10).isActive = true
        
        self.dateLabel.leftAnchor.constraint(equalTo: self.bgView.leftAnchor, constant: 10).isActive = true
        self.dateLabel.topAnchor.constraint(equalTo: self.conditionLabel.bottomAnchor, constant: 10).isActive = true
        self.dateLabel.bottomAnchor.constraint(equalTo: self.bgView.bottomAnchor, constant: -10).isActive = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
