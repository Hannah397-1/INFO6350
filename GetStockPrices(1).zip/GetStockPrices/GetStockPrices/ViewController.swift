//
//  ViewController.swift
//  GetStockPrices
//
//  Created by Drillmaps on 10/12/22.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    

    @IBOutlet weak var tblView: UITableView!
    var stocks : [StockModel] = [StockModel]()
    var indexSelected = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initStocks()
    }

    func initStocks(){
        
        self.stocks = [StockModel]()
                AF.request(allURL).responseJSON { responseData in
        //            SwiftSpinner.hide()
                    print(responseData)
                    if responseData.error != nil {
                        print(responseData.error!)
                        return
                    }
                    let stockData = JSON(responseData.data as Any)
                    self.stocks = [StockModel]()
                    for stock in stockData{
                        let ele = StockModel()
                        let stockJSON = JSON(stock.1)
                        ele.companyName = stockJSON["CompanyName"].stringValue
                        ele.price = stockJSON["Price"].doubleValue
                        ele.symbol = stockJSON["Symbol"].stringValue
                        self.stocks.append(ele)
                    }
                    self.tblView.reloadData()
                }
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stocks.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = "\(stocks[indexPath.row].companyName)(\(stocks[indexPath.row].symbol)): \(stocks[indexPath.row].price)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        // Send the symbol to next VC
        indexSelected = indexPath.row
        performSegue(withIdentifier: "segueDetails", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "segueDetails" {
                let secondVC = segue.destination as! DetailsViewController
                let stock = stocks[indexSelected]
                
                secondVC.companyName = stock.companyName
                secondVC.price = stock.price
                secondVC.symbol = stock.symbol
            }
        }
}

