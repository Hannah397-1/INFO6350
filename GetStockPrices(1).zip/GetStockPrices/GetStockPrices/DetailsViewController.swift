//
//  DetailsViewController.swift
//  GetStockPrices
//
//  Created by Drillmaps on 10/12/22.
//

import UIKit

class DetailsViewController: UIViewController {


    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblSymbol: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    
    var companyName = ""
    var symbol = ""
    var price = 0.0

    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblCompanyName?.text = "Company Name: \(companyName)"
        lblPrice?.text = "Price: \(price)"
        lblSymbol?.text = "Symbol: \(symbol)"

        // Do any additional setup after loading the view.
    }


}
