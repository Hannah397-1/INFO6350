//
//  NetworkFunction.swift
//  GetStockPrices
//
//  Created by xiaohan on 12/10/22.
//

import Foundation

func getCompanyQuoteURL(_ symbol : String) -> String {
    let url = "\(basicurl)getstock?symbol=\(symbol)"
    return url
}

