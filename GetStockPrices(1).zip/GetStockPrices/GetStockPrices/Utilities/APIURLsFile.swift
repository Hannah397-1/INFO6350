//
//  APIURLsFile.swift
//  GetStockPrices
//
//  Created by xiaohan on 12/10/22.
//

import Foundation

let basicurl = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/"
let allURL = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/allstocks"

