//
//  StockModel.swift
//  GetStockPrices
//
//  Created by xiaohan on 12/10/22.
//

import Foundation

class StockModel{
    
    var companyName = ""
    var symbol = ""
    var price = 0.0
    
}
